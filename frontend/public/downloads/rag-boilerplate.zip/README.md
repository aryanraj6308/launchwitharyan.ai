# RAG Conversational Boilerplate

A production-ready Retrieval-Augmented Generation template with FastAPI, Supabase PGVector, and dynamic prompt logging.

## Stack

- **Backend**: FastAPI + SQLAlchemy + Supabase PGVector
- **Frontend**: HTML/CSS/JS chat UI with prompt log viewer
- **AI**: OpenAI API or local Ollama (Llama 3)
- **Auth**: JWT token-based session management
- **Rate Limiting**: SlowAPI middleware on all endpoints

## Quick Start

### Backend

```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend

Open `frontend/index.html` in a browser or serve with:

```bash
cd frontend
python -m http.server 3000
```

## Endpoints

| Route | Description |
|---|---|
| POST /api/chat | Send a message to the RAG agent |
| GET /api/logs | Retrieve prompt/response history |
| POST /api/ingest | Upload a document for vector indexing |
| GET /api/health | Health check |

## PGVector Schema

The vector store schema is in `app/database.py`. It creates a `document_embeddings` table with a 1536-dimensional vector column for OpenAI embeddings, plus a cosine-similarity search function.
