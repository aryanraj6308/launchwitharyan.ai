from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from slowapi import Limiter

from app.database import get_db, DocumentChunk
from app.schemas import IngestRequest, IngestResponse
from app.security import get_rate_limit_key, sanitize_input
from app.routers.embeddings import embed_query

router = APIRouter(prefix="/api", tags=["Ingest"])
limiter = Limiter(key_func=get_rate_limit_key)


@router.post("/ingest", response_model=IngestResponse)
@limiter.limit("10/minute")
async def ingest_document(
    request: Request,
    payload: IngestRequest,
    db: Session = Depends(get_db),
):
    content = sanitize_input(payload.content)
    chunks = [content[i:i+1000] for i in range(0, len(content), 1000)]

    from sqlalchemy import text
    for chunk_text in chunks:
        chunk = DocumentChunk(content=chunk_text, source=payload.source)
        db.add(chunk)
        db.flush()

        vector = await embed_query(chunk_text)
        vec_str = "[" + ",".join(str(v) for v in vector) + "]"
        db.execute(
            text("INSERT INTO document_embeddings (chunk_id, embedding) VALUES (:cid, :vec::vector)"),
            {"cid": chunk.id, "vec": vec_str},
        )

    db.commit()
    return IngestResponse(status="success", chunks_count=len(chunks))
