import time
import httpx
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from slowapi import Limiter

from app.config import settings
from app.database import get_db, PromptLog
from app.schemas import ChatRequest, ChatResponse
from app.security import get_rate_limit_key, sanitize_input
from app.routers.embeddings import embed_query, search_similar

router = APIRouter(prefix="/api", tags=["Chat"])
limiter = Limiter(key_func=get_rate_limit_key)

SYSTEM_PROMPT = (
    "You are an expert RAG assistant. Use the provided context to answer accurately. "
    "If the context doesn't contain the answer, say so. Keep responses concise."
)


async def query_ollama(prompt: str, context: str) -> str:
    url = f"{settings.OLLAMA_URL}/api/generate"
    payload = {
        "model": "llama3",
        "prompt": f"Context:\n{context}\n\nQuestion: {prompt}\n\nAnswer:",
        "stream": False,
        "options": {"temperature": settings.TEMPERATURE, "num_predict": settings.MAX_TOKENS},
    }
    async with httpx.AsyncClient(timeout=60.0) as client:
        res = await client.post(url, json=payload)
        res.raise_for_status()
        return res.json().get("response", "")


async def query_openai(prompt: str, context: str) -> str:
    from openai import AsyncOpenAI

    client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
    res = await client.chat.completions.create(
        model=settings.CHAT_MODEL,
        messages=[
            {"role": "system", "content": f"{SYSTEM_PROMPT}\n\nRelevant context:\n{context}"},
            {"role": "user", "content": prompt},
        ],
        max_tokens=settings.MAX_TOKENS,
        temperature=settings.TEMPERATURE,
    )
    return res.choices[0].message.content or ""


@router.post("/chat", response_model=ChatResponse)
@limiter.limit(lambda: f"{settings.RATE_LIMIT_PER_MINUTE}/minute")
async def chat(request: Request, payload: ChatRequest, db: Session = Depends(get_db)):
    start = time.perf_counter()
    message = sanitize_input(payload.message)
    session_id = payload.session_id or f"session_{int(time.time())}"

    context_chunks = await search_similar(message, db)
    context = "\n\n".join(context_chunks) if context_chunks else "No relevant context found."
    sources = context_chunks[:3] if context_chunks else []

    has_openai = settings.OPENAI_API_KEY and settings.OPENAI_API_KEY.startswith("sk-")
    try:
        if has_openai:
            reply = await query_openai(message, context)
        else:
            reply = await query_ollama(message, context)
    except Exception:
        reply = "I'm running in offline mode. Configure OPENAI_API_KEY or start a local Ollama instance."

    latency = int((time.perf_counter() - start) * 1000)

    log = PromptLog(
        session_id=session_id,
        prompt=message,
        response=reply,
        model_used=settings.CHAT_MODEL if has_openai else "ollama/llama3",
        latency_ms=latency,
    )
    db.add(log)
    db.commit()

    return ChatResponse(reply=reply, session_id=session_id, sources=sources)
