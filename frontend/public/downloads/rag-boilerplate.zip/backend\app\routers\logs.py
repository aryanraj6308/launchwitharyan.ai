from fastapi import APIRouter, Depends, Request, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc
from slowapi import Limiter

from app.database import get_db, PromptLog
from app.schemas import LogListResponse, LogEntry
from app.security import get_rate_limit_key

router = APIRouter(prefix="/api", tags=["Logs"])
limiter = Limiter(key_func=get_rate_limit_key)


@router.get("/logs", response_model=LogListResponse)
@limiter.limit("30/minute")
async def list_logs(
    request: Request,
    session_id: str = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    query = db.query(PromptLog).order_by(desc(PromptLog.created_at))
    if session_id:
        query = query.filter(PromptLog.session_id == session_id)

    total = query.count()
    logs = query.offset(offset).limit(limit).all()

    return LogListResponse(
        logs=[
            LogEntry(
                id=log.id,
                session_id=log.session_id,
                prompt=log.prompt,
                response=log.response,
                model_used=log.model_used,
                tokens_used=log.tokens_used,
                latency_ms=log.latency_ms,
                created_at=str(log.created_at) if log.created_at else None,
            )
            for log in logs
        ],
        total=total,
    )
