from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str = ""
    OPENAI_API_KEY: str = ""
    OLLAMA_URL: str = "http://localhost:11434"
    SECRET_KEY: str = "change-me-to-a-random-256-bit-secret"
    RATE_LIMIT_PER_MINUTE: int = 20
    VECTOR_DIMENSION: int = 1536
    COLLECTION_NAME: str = "documents"
    MAX_TOKENS: int = 512
    TEMPERATURE: float = 0.7
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    CHAT_MODEL: str = "gpt-4o-mini"

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
