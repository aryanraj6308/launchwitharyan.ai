from typing import Optional
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.config import settings


async def embed_query(text: str) -> list[float]:
    if settings.OPENAI_API_KEY and settings.OPENAI_API_KEY.startswith("sk-"):
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        res = await client.embeddings.create(
            model=settings.EMBEDDING_MODEL,
            input=text,
        )
        return res.data[0].embedding

    import hashlib
    seed = hashlib.sha256(text.encode()).digest()
    import random
    rng = random.Random(seed)
    return [rng.gauss(0, 1) for _ in range(settings.VECTOR_DIMENSION)]


async def search_similar(query: str, db: Session, top_k: int = 3) -> list[str]:
    try:
        vector = await embed_query(query)
        vec_str = "[" + ",".join(str(v) for v in vector) + "]"
        sql = text("""
            SELECT dc.content
            FROM match_documents(:vec::vector, 0.7, :top_k) md
            JOIN document_chunks dc ON dc.id = md.chunk_id
        """)
        rows = db.execute(sql, {"vec": vec_str, "top_k": top_k}).fetchall()
        return [row[0] for row in rows]
    except Exception:
        return []
