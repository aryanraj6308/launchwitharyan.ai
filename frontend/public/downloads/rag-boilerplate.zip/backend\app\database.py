from sqlalchemy import create_engine, Column, String, Text, Float, DateTime, Integer, func
from sqlalchemy.orm import sessionmaker, declarative_base
import uuid

from app.config import settings

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    content = Column(Text, nullable=False)
    source = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class PromptLog(Base):
    __tablename__ = "prompt_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String, nullable=False)
    prompt = Column(Text, nullable=False)
    response = Column(Text, nullable=False)
    model_used = Column(String, nullable=True)
    tokens_used = Column(Integer, nullable=True)
    latency_ms = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_tables():
    Base.metadata.create_all(bind=engine)

    with engine.connect() as conn:
        conn.execute(
            text("CREATE EXTENSION IF NOT EXISTS vector;")
        )
        conn.execute(
            text(f"""
                CREATE TABLE IF NOT EXISTS document_embeddings (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    chunk_id TEXT REFERENCES document_chunks(id),
                    embedding vector({settings.VECTOR_DIMENSION}),
                    created_at TIMESTAMPTZ DEFAULT NOW()
                );
            """)
        )
        conn.execute(
            text("""
                CREATE OR REPLACE FUNCTION match_documents(
                    query_embedding vector(1536),
                    match_threshold float,
                    match_count int
                )
                RETURNS TABLE(id UUID, chunk_id TEXT, content TEXT, similarity float)
                LANGUAGE sql STABLE
                AS $$
                    SELECT
                        de.id,
                        de.chunk_id,
                        dc.content,
                        1 - (de.embedding <=> query_embedding) AS similarity
                    FROM document_embeddings de
                    JOIN document_chunks dc ON dc.id = de.chunk_id
                    WHERE 1 - (de.embedding <=> query_embedding) > match_threshold
                    ORDER BY similarity DESC
                    LIMIT match_count;
                $$;
            """)
        )
        conn.commit()
