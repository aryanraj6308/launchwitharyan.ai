import re
import time
from fastapi import Request, HTTPException, status

MAX_MESSAGE_LEN = 10000

SSTI_PATTERNS = re.compile(
    r"\$\{.*?\}|\{\{.*?\}\}|\{\%.*?\%\}|<%.*?%>|\#\{.*?\}",
    re.IGNORECASE,
)

SQL_INJECTION_PATTERNS = re.compile(
    r"(\bOR\b|\bAND\b|\bUNION\b|\bSELECT\b|\bDROP\b|\bDELETE\b|\bINSERT\b|\bUPDATE\b|\bEXEC\b)",
    re.VERBOSE | re.IGNORECASE,
)


def sanitize_input(value: str) -> str:
    value = value.strip()
    if SSTI_PATTERNS.search(value):
        raise HTTPException(status_code=400, detail="Forbidden template syntax.")
    if SQL_INJECTION_PATTERNS.search(value):
        raise HTTPException(status_code=400, detail="Forbidden SQL keywords.")
    return value


def get_rate_limit_key(request: Request) -> str:
    ip = request.client.host if request.client else "unknown"
    return f"{ip}:{request.url.path}"
