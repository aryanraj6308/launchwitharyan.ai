const API = 'http://localhost:8000';
let sessionId = localStorage.getItem('rag_session') || crypto.randomUUID();
localStorage.setItem('rag_session', sessionId);

document.getElementById('session-badge').textContent = `Session: ${sessionId.slice(0, 8)}...`;

// Tab switching
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
  });
});

// Chat
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const messages = document.getElementById('messages');

chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = chatInput.value.trim();
  if (!msg) return;

  appendMessage(msg, 'user');
  chatInput.value = '';

  const bubble = appendMessage('Thinking...', 'bot');

  try {
    const res = await fetch(`${API}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg, session_id: sessionId }),
    });
    const data = await res.json();
    bubble.innerHTML = data.reply;
    if (data.sources && data.sources.length) {
      bubble.innerHTML += `<div class="sources">Sources: ${data.sources.length} chunks</div>`;
    }
  } catch {
    bubble.innerHTML = 'Error: Could not reach the RAG API. Is the backend running on port 8000?';
  }
});

function appendMessage(text, sender) {
  const div = document.createElement('div');
  div.className = `message ${sender}`;
  div.innerHTML = `<div class="avatar">${sender === 'user' ? 'U' : 'R'}</div><div class="bubble">${text}</div>`;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
  return div.querySelector('.bubble');
}

// Logs
document.getElementById('refresh-logs').addEventListener('click', loadLogs);

async function loadLogs() {
  const container = document.getElementById('logs-container');
  container.innerHTML = '<p class="empty-state">Loading...</p>';

  try {
    const res = await fetch(`${API}/api/logs?session_id=${sessionId}&limit=50`);
    const data = await res.json();

    if (!data.logs.length) {
      container.innerHTML = '<p class="empty-state">No logs yet.</p>';
      return;
    }

    container.innerHTML = data.logs.map(log => `
      <div class="log-entry">
        <div class="meta">
          <span>${log.created_at || ''}</span>
          <span>${log.model_used || '—'}</span>
          <span>${log.latency_ms || '—'}ms</span>
        </div>
        <div class="prompt"><strong>Q:</strong> ${escapeHtml(log.prompt)}</div>
        <div class="response"><strong>A:</strong> ${escapeHtml(log.response)}</div>
      </div>
    `).join('');
  } catch {
    container.innerHTML = '<p class="empty-state">Failed to load logs. Is the backend running?</p>';
  }
}

function escapeHtml(text) { return text.replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]); }

// Ingest
document.getElementById('ingest-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const content = document.getElementById('ingest-content').value.trim();
  const source = document.getElementById('ingest-source').value.trim();
  if (!content) return;

  const status = document.getElementById('ingest-status');
  status.textContent = 'Ingesting...';

  try {
    const res = await fetch(`${API}/api/ingest`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, source: source || null }),
    });
    const data = await res.json();
    if (data.status === 'success') {
      status.innerHTML = `<span style="color: #22c55e">✓ ${data.chunks_count} chunk(s) ingested and vectorized.</span>`;
      document.getElementById('ingest-content').value = '';
    } else {
      status.textContent = 'Error: ' + (data.detail || 'Unknown error');
    }
  } catch (err) {
    status.textContent = 'Error: ' + err.message;
  }
});
