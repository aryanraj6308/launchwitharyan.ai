import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from app.config import settings
from app.database import create_tables
from app.routers import chat, ingest, logs
from app.security import get_rate_limit_key

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("rag-boilerplate")

limiter = Limiter(key_func=get_rate_limit_key, default_limits=["60/minute"])


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting RAG Boilerplate API...")
    create_tables()
    yield
    logger.info("Shutting down.")


app = FastAPI(
    title="RAG Conversational Boilerplate",
    version="1.0.0",
    lifespan=lifespan,
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    return response


@app.get("/api/health")
async def health():
    return {"status": "healthy", "service": "RAG Boilerplate"}


app.include_router(chat.router)
app.include_router(ingest.router)
app.include_router(logs.router)
