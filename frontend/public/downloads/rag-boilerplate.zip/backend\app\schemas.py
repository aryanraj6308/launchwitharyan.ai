from pydantic import BaseModel, field_validator
from typing import Optional


class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    temperature: Optional[float] = None

    @field_validator("message")
    @classmethod
    def validate_message(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Message cannot be empty.")
        if len(v) > 10000:
            raise ValueError("Message too long.")
        return v


class ChatResponse(BaseModel):
    reply: str
    session_id: str
    sources: list[str] = []


class LogEntry(BaseModel):
    id: int
    session_id: str
    prompt: str
    response: str
    model_used: Optional[str]
    tokens_used: Optional[int]
    latency_ms: Optional[int]
    created_at: Optional[str]

    class Config:
        from_attributes = True


class LogListResponse(BaseModel):
    logs: list[LogEntry]
    total: int


class IngestRequest(BaseModel):
    content: str
    source: Optional[str] = None

    @field_validator("content")
    @classmethod
    def validate_content(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Content cannot be empty.")
        if len(v) > 50000:
            raise ValueError("Content too long.")
        return v


class IngestResponse(BaseModel):
    status: str
    chunks_count: int
